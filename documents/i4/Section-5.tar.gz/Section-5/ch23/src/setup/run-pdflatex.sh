pdfl=`cat /home/=user=/gits/=repo=/ar/../preferred/preferred-latex`
pdfl=${pdfl/\~\//$HOME/}
echo $pdfl
TEXINPUTS=/home/=path=/ch22/src:/home/=path=/ch22/figures:/home/=path=/ch22/extra:: $pdfl -jobname=ch22 -synctex=1 -interaction=nonstopmode --shell-escape -output-dir=../../out  /home/=path=/src/ch22.prep.tex

 
