
OVERVIEW
--------

This file will outline the source files included in the five sibling chapter-folders, hopefully to aid those processing and/or converting the latex files to understand the commands and folder-structure employed.

As a point of reference, PDF files for the five chapters are provided within this top-level folder.  Obviously, the layout and typesetting for the published chapters wil probably look somewhat different depending on the house style, but viewing PDF generated directly from the existing sources may clarify some features of the original sources themselves.

Note that the authors did not compose these documents in Latex directly, but rather in a formal called GTagML (hence the extension .gt), which is loosely based on TagML (the Text-as-Graph Markup Language originally developed at Netherlands Academy of Arts and Sciences).  The .gt files are converted to .tex sources, and during this process they are also scanned to extract some basic natural-language features, such as sentence and paragraph boundaries.  This is not achieved via "Natural Language Processing" per se, but rather through certain rules and conventions of the GTagML format which stipulate (for example) how end-of-sentence punctuation should be distinguished from symbols with different discursive purposes (such as dots within an abbreviation).

The GTagML-LaTeX conversion is one step in an extended pipeline whose goal is to cross-reference discursive features (like sentence boundaries) with PDF page coordinates (and, by extension, PDF-viewer screen coordinates), in order to achieve features such as readers selecting a complete sentence as one context-menu option upon clicking near any word in a sentence (instead of making such a selection by dragging the mouse over from the start of its first word to the end of its last, which is much more cumbersome).  In prior publications I (Nathaniel Christen) have included custom PDF viewers and embedded metadata files to support this kind of functionality, as part of data sets published alongside the articles themselves.  

Of course, any pdfcoord mapping would presumably no longer be preserved when migrating files to a camera-ready format consistent with the larger volume, so the metadata files (such as those in the .ntxh and .htxn formats) may cease to be useful, but this collection of source files preserves some of the programming needed to generate those files.  In particular, note that a few LaTeX commands (such as \>) are redefined and interspersed through the files (the \>, for instance, marks a text-point and space between two sentences).  I described the GTagML workflow to explain the origin of these commands, which might be enigmatic otherwise.

One facet of the .gt->.tex conversion is to generate a series of .tex files and a specific folder-structure that incorporates text-point metadata, which is needed for the pdflatex process to operate (without getting tripped up on special or repurposed commands such as \>).  This is the rationale for "ngml" folders, for example, and for the .gt files preserved in the chapter sources.  The latter files would not come into play for latex-specific tasks, but are kept in the folders because they may be more readable than the .tex sources, in case a need arises to consult the text directly.  Other files are related to machine-readable encoding for text mining (which I'll briefly mention at the end).

Fully polishing the .gt->.tex process occasionally requires special commands within the original .gt files, and we did not have time before submitting these five chapters to create perfected .gt sources.  As a result, there are a few layout anomalies which we addressed by minor adjustments, such as spacing commands, and occasionally the text-point commands are in the wrong place (notably there are locations where a sentence-start command at the beginning of a paragraph comes before, rather than after, an annotation-command).  These anomalies do not visually affect the generated PDFs but they might cause confusion for someone looking at the LaTeX files without an explanation for certain instructions whose purpose is not obvious a priori.

Because numerous files and folders are auto-generated, there is a lot of duplicate content between different chapters.  In theory, for processing multiple chapters at once it might be convenient to factor shared commands into shared sources.  However, we have engineered this set so that each chapter can be worked on in isolation.  This is what we did for prior composited publications, and we have not received feedback suggesting that publishers preferred a model where there were interdependencies between chapters.


PDFLATEX
--------
When generating the .tex sources the software also creates a shell script to invoke pdflatex, and also generates the top-level .tex file to pass to the pdflatex program.  These latter files have the compound suffix .prep.tex, so files matching this pattern should be considered the actual source files, as compared to the files with similar names but only a .tex extension (e.g., ch20.prep.tex instead of ch20.tex).  The necessary shell scripts are in the "setup" folders for each chapter.  Presumably these scripts need to be edited for different systems, but note that given the chapters' internal directory layout it is probably necessary to invoke pdflatex (or analogous programs) from a script rather than the command line).  
 

BIBLIOGRAPHY
------------
Almost every referenced work is provided with a link to an online version.  Due to time constraints we were not able to provide full citations, but we hope the existing links make it easy to fill in further details about (e.g.) journal volume as needed.

    
ACRONYMS
--------
Most acronyms used in the chapters are assigned their own LaTeX commands and give special formatting.  Apart from visually distinguishing these character-strings this may help with compiling an index or glossary for documents where that step is taken.  We prefer all-caps acronyms to be given a style where they are smaller in size than normal caps, somewhere between the height of capital and lower-cases letters, though of course these decisions can vary depending on publishers' "house" styles.

One comment about acronyms is that there are ambiguous cases where it is unclear whether to typeset a term as an acronym or an ordinary word.  For example, many programming languages or tools have acronym or abbreviation names (LLVM, GCC, SQL, XML, CSS, MATLAB) there are many cases where the historical origin of a name has been superceded (Perl, PHP, Lisp) and others  
whose names are more quixotic (Python, Java, Lisp).  There are also admixtures of full words or syllables with acronyms (OpenCV, GraphML, XQuery).  Because many acronyms are technical terms or abbreviations, formatting them with a distinct style arguably creates an expectation for readers that similar terms have a similar style, even if they are derived from "normal" words (like Python, say).  For these reasons, we have tended to apply the acronym styling in many of these cases, including for mixtures of lowercase and uppercase letters.

When acronyms (or similarly formatted terms) appear at the start of a sentence, some guidelines recommend simply spelling out the full phrase;   using the same format as in mid-sentence can be confusing.  We prefer to adopt the (admittedly idiosyncratic) convention of preserving the acronym format but making the initial letter somewhat larger.  Although ideally this could be done with a single LaTeX command which works for acronyms in multiple contexts (mid-sentence, start-sentence, footnotes, etc.) -- perhaps via an additional optional parameter -- here for simplicity's sake we just created additional commands for special-format acronyms as needed (e.g., preceding the command-name with a lower-case "l" for start-of-sentence).

Probably it is best to wrap most acronyms in "makebox" commands to prevent internal hyphenation.  We did not do this as a rule in these sources in case there are house guidelines in effect for hyphenating "normal" words which we treat here as akin to acronyms, such as JavaScript.  




