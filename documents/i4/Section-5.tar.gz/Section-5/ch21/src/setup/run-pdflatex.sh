pdfl=`cat /home/=user=/gits/=repo=/ar/../preferred/preferred-latex`
pdfl=${pdfl/\~\//$HOME/}
echo $pdfl
TEXINPUTS=/home/=path=/ch21/src:/home/=path=/ch21/figures:/home/=path=/ch21/extra:: $pdfl -jobname=ch21 -synctex=1 -interaction=nonstopmode --shell-escape -output-dir=../../out  /home/=path=/src/ch21.prep.tex

 
